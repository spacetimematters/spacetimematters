A Pen created at CodePen.io. You can find this one at https://codepen.io/soulwire/pen/foktm.

 sketch.js is a tiny (~5k) boilerplate for creating JavaScript based creative coding experiments. This demo shows what can be done with just a few lines of code.

https://github.com/soulwire/sketch.js